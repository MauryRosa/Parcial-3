const express = require('express');
const router = express.Router();
const Usuario = require('../models/Usuario');

// POST /api/usuarios - Registrar nuevo usuario
router.post('/', async (req, res) => {
    try {
        const { nombre, direccion, telefono, referencia, observacion, creditos, plan } = req.body;

        const usuario = new Usuario({
            nombre,
            direccion,
            telefono,
            referencia,
            observacion,
            creditos,
            plan
        });

        await usuario.save();
        res.status(201).json({ message: 'Usuario registrado con éxito', usuario });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al registrar el usuario' });
    }
});

module.exports = router;
