const express = require('express');
const router = express.Router();
const Envio = require('../models/Envio');
const Producto = require('../models/Producto');
const Usuario = require('../models/Usuario');

// GET /api/envios - Listar todos los envíos
router.get('/', async (req, res) => {
    try {
        const envios = await Envio.find().populate('usuarioId');
        res.json(envios);
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al obtener los envíos' });
    }
});

// GET /api/envios/usuario/:usuarioId/disponibles
router.get('/usuario/:usuarioId/disponibles', async (req, res) => {
    try {
        const { usuarioId } = req.params;

        const usuario = await Usuario.findById(usuarioId);
        if (!usuario) {
            return res.status(404).json({ error: 'Usuario no encontrado' });
        }

        const enviosUsados = await Envio.find({ usuarioId });

        const usados = enviosUsados.length;
        const disponibles = usuario.totalEnviosComprados - usados;

        res.json({
            usuario: usuario.nombre,
            totalComprados: usuario.totalEnviosComprados,
            usados,
            disponibles,
            envios: enviosUsados.map(envio => ({
                id: envio._id,
                producto: envio.producto,
                costo: envio.costo,
                estatus: envio.estatus
            }))
        });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al obtener datos del usuario' });
    }
});



// POST /api/envios - Registrar un nuevo envío
router.post('/', async (req, res) => {
    try {
        const { usuarioId, descripcion, peso, bultos, fecha_entrega, observacion } = req.body;

        const usuario = await Usuario.findById(usuarioId);
        if (!usuario) return res.status(404).json({ error: 'Usuario no encontrado' });

        if (usuario.creditos <= 0) {
            return res.status(400).json({ error: 'Usuario sin créditos disponibles' });
        }

        // Calcular costo según peso
        const bloques = Math.ceil(peso / 3); // Cada 3 lb cuenta como 1 crédito
        const costoUnitario = {
            'plan30': 4.5,
            'plan40': 4.0,
            'plan60': 3.0
        }[usuario.plan] || 4.5;

        const costoFinal = bloques * costoUnitario;

        // Crear producto
        const producto = new Producto({ descripcion, peso, bultos, fecha_entrega });
        await producto.save();

        // Crear envío
        const envio = new Envio({
            usuarioId,
            productoId: producto._id,
            observacion,
            costoFinal
        });
        await envio.save();

        // Restar créditos al usuario
        usuario.creditos -= 1;
        await usuario.save();

        res.status(201).json({ message: 'Envío registrado', envio });

    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al registrar el envío' });
    }
});

// DELETE /api/envios/:id - Eliminar un envío y devolver el saldo al usuario
router.delete('/:id', async (req, res) => {
    try {
        const envio = await Envio.findById(req.params.id);
        if (!envio) {
            return res.status(404).json({ error: 'Envío no encontrado' });
        }

        // Obtener al usuario
        const usuario = await Usuario.findById(envio.usuarioId);
        if (!usuario) {
            return res.status(404).json({ error: 'Usuario no encontrado' });
        }

        const COSTO_ENVIO = 10;

        usuario.saldo += COSTO_ENVIO;
        await usuario.save();

        // Eliminar el envío
        await envio.deleteOne();

        res.json({ message: 'Envío eliminado y saldo reembolsado al usuario' });
    } catch (error) {
        console.error(error);
        res.status(500).json({ error: 'Error al eliminar el envío' });
    }
});

module.exports = router;

