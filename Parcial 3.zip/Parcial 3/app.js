const express = require('express');
const mongoose = require('mongoose');
const app = express();

const envioRoutes = require('./routes/envio.routes');
const usuarioRoutes = require('./routes/usuario.routes');

app.use(express.json());
app.use('/api/envios', envioRoutes);
app.use('/api/usuarios', usuarioRoutes);

mongoose.connect('mongodb://localhost:27017/postmail', {
    useNewUrlParser: true,
    useUnifiedTopology: true
}).then(() => console.log(' Conectado a MongoDB'))
  .catch(err => console.error(' Error conectando a MongoDB', err));

const PORT = process.env.PORT || 8000;
app.listen(PORT, () => console.log(` Servidor escuchando en puerto ${PORT}`));
