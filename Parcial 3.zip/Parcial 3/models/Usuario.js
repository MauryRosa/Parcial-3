const mongoose = require('mongoose');

const usuarioSchema = new mongoose.Schema({
    nombre: String,
    direccion: String,
    telefono: String,
    referencia: String,
    observacion: String,
    creditos: Number,
    plan: String,
    saldo: Number,         
    totalEnviosComprados: Number
});

module.exports = mongoose.model('Usuario', usuarioSchema);
