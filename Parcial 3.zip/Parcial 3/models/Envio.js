const mongoose = require('mongoose');

const envioSchema = new mongoose.Schema({
    usuarioId: { type: mongoose.Schema.Types.ObjectId, ref: 'Usuario' },
    productoId: { type: mongoose.Schema.Types.ObjectId, ref: 'Producto' },
    observacion: String,
    costoFinal: Number,
    fechaRegistro: { type: Date, default: Date.now }
});

module.exports = mongoose.model('Envio', envioSchema);
